# 🟡 Gold Signal Bot — ربات تحلیل قیمت طلای ۱۸ عیار ایران

ربات پایتونی که هر ۵ دقیقه یک‌بار (از طریق GitHub Actions):

1. قیمت لحظه‌ای طلای ۱۸ عیار را از `tgju.org` دریافت می‌کند
2. آن را در تاریخچه‌ای (CSV) ذخیره می‌کند تا سری زمانی شکل بگیرد
3. اندیکاتورهای **MACD، RSI، EMA، SMA، ADX، ATR، Bollinger Bands** را محاسبه می‌کند
4. روند (صعودی/نزولی/خنثی) و قدرت سیگنال (۰ تا ۱۰۰٪) را تحلیل می‌کند
5. گزارش کامل را به یک چت/کانال تلگرام ارسال می‌کند

## 📂 ساختار پروژه

```
gold-signal-bot/
├── main.py                     # نقطه ورود؛ هماهنگ‌کننده تمام مراحل
├── config.py                   # تنظیمات و متغیرهای محیطی
├── gold_price_fetcher.py       # دریافت قیمت طلا از tgju.org
├── storage.py                  # ذخیره/بازیابی تاریخچه قیمت (CSV)
├── indicators.py                # محاسبه اندیکاتورهای تکنیکال
├── signal_analyzer.py          # تشخیص روند و قدرت سیگنال
├── telegram_notifier.py        # ارسال پیام به تلگرام
├── requirements.txt
├── .env.example
├── data/
│   └── price_history.csv       # (خودکار ساخته می‌شود)
└── .github/workflows/gold-bot.yml   # اجرای خودکار هر ۵ دقیقه
```

## ⚙️ راه‌اندازی

### ۱. ساخت بات تلگرام
1. در تلگرام به [@BotFather](https://t.me/BotFather) پیام دهید و `/newbot` را بزنید.
2. توکن داده‌شده را نگه دارید (`TELEGRAM_BOT_TOKEN`).
3. برای پیدا کردن `chat_id`:
   - چت خصوصی: به [@userinfobot](https://t.me/userinfobot) پیام دهید.
   - گروه/کانال: بات را عضو کنید، یک پیام بفرستید، سپس با API زیر آی‌دی را بگیرید:
     `https://api.telegram.org/bot<TOKEN>/getUpdates`

### ۲. اجرای لوکال (تست)
```bash
git clone <این-ریپازیتوری>
cd gold-signal-bot
python -m venv venv && source venv/bin/activate   # ویندوز: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# مقادیر TELEGRAM_BOT_TOKEN و TELEGRAM_CHAT_ID را در .env وارد کنید

# اجرای دستی یک بار
python main.py
```

> 💡 چون در ابتدا داده‌ی کافی برای اندیکاتورها وجود ندارد (به‌طور پیش‌فرض به ۳۵ کندل نیاز است)،
> برای تست سریع می‌توانید `MIN_CANDLES_REQUIRED` را در `.env` موقتاً کم کنید، یا اسکریپت را
> چندین بار پشت‌سرهم اجرا کنید، یا `USE_MOCK_PRICE=true` بگذارید تا داده مصنوعی تولید شود.

### ۳. راه‌اندازی روی GitHub Actions (اجرای خودکار هر ۵ دقیقه)

1. این پروژه را در یک ریپازیتوری روی GitHub Push کنید.
2. به `Settings → Secrets and variables → Actions` بروید و دو Secret زیر را اضافه کنید:
   - `TELEGRAM_BOT_TOKEN`
   - `TELEGRAM_CHAT_ID`
3. مطمئن شوید در `Settings → Actions → General → Workflow permissions`
   گزینه‌ی **Read and write permissions** فعال باشد (برای اینکه Actions بتواند
   فایل تاریخچه‌ی قیمت را commit کند).
4. وورک‌فلوی `.github/workflows/gold-bot.yml` به‌صورت خودکار هر ۵ دقیقه اجرا می‌شود.
   برای تست فوری، از تب **Actions → Gold Signal Bot → Run workflow** استفاده کنید.

## 📊 درباره‌ی اندیکاتورها

| اندیکاتور | کاربرد در این پروژه |
|---|---|
| SMA / EMA | تشخیص جهت روند نسبت به میانگین متحرک |
| RSI | تشخیص اشباع خرید/فروش |
| MACD | تشخیص مومنتوم و تقاطع خط سیگنال |
| Bollinger Bands | موقعیت قیمت نسبت به نوسان اخیر |
| ADX | قدرت/اعتبار روند (نه جهت آن) |
| ATR | میزان نوسان بازار |

چون قیمت طلا هر ۵ دقیقه به‌صورت یک عدد (نه کندل) دریافت می‌شود، این داده‌ها در
بازه‌های `RESAMPLE_RULE` (پیش‌فرض ۱۵ دقیقه) به کندل OHLC تبدیل می‌شوند تا
اندیکاتورهایی مثل ADX/ATR که به High/Low نیاز دارند قابل‌محاسبه باشند.

## ⚠️ نکات مهم

- **پایداری منبع قیمت:** `gold_price_fetcher.py` با اسکرپ HTML صفحه‌ی
  `tgju.org/profile/geram18` کار می‌کند. اگر ساختار سایت تغییر کند، ممکن است
  نیاز به به‌روزرسانی سلکتورها در همان فایل باشد. در صورت نیاز به منبع
  پایدارتر، می‌توانید از APIهای پولی مثل navasan.tech یا brsapi.ir استفاده کنید.
- **این پروژه ابزار آموزشی/کمکی است، نه توصیه‌ی مالی.** تحلیل تکنیکال احتمالی
  است و تصمیم خرید/فروش باید با مسئولیت خودتان و در نظر گرفتن منابع بیشتر انجام شود.
- فایل `data/price_history.csv` به‌مرور بزرگ می‌شود؛ تابع `trim_history()` در
  `storage.py` آن را به‌صورت خودکار به ۲۰٬۰۰۰ ردیف آخر محدود می‌کند.
