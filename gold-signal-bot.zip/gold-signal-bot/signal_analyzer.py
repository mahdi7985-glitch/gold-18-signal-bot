"""
signal_analyzer.py
-------------------
با ترکیب اندیکاتورهای مختلف، یک تحلیل ترکیبی از روند (Trend) و قدرت سیگنال
(Signal Strength) تولید می‌کند. منطق این ماژول یک روش رایج و ساده‌ی
تحلیل تکنیکال است، نه یک مدل مالی تضمین‌شده؛ صرفاً برای کمک به تصمیم‌گیری
است و نباید به‌تنهایی مبنای تصمیم مالی قرار گیرد.

امتیازدهی:
    هر اندیکاتور بین -2 (بسیار نزولی) تا +2 (بسیار صعودی) امتیاز می‌دهد.
    مجموع امتیازها نرمالایز شده و به یک برچسب روند + درصد قدرت سیگنال
    (۰ تا ۱۰۰) تبدیل می‌شود.
"""

from dataclasses import dataclass, field
import pandas as pd


@dataclass
class SignalResult:
    trend: str  # "صعودی قوی" | "صعودی" | "خنثی" | "نزولی" | "نزولی قوی"
    strength: int  # 0..100
    reasons: list[str] = field(default_factory=list)


def _score_macd(row: pd.Series) -> tuple[float, str]:
    diff = row["macd_hist"]
    if diff > 0 and row["macd"] > row["macd_signal"]:
        return (2 if diff > abs(row["macd"]) * 0.15 else 1), "MACD بالای خط سیگنال (مومنتوم صعودی)"
    if diff < 0 and row["macd"] < row["macd_signal"]:
        return (-2 if abs(diff) > abs(row["macd"]) * 0.15 else -1), "MACD زیر خط سیگنال (مومنتوم نزولی)"
    return 0, "MACD در وضعیت خنثی/تقاطع"


def _score_rsi(row: pd.Series) -> tuple[float, str]:
    rsi = row["rsi"]
    if rsi >= 70:
        return -1, f"RSI={rsi:.1f} در محدوده اشباع خرید (احتمال اصلاح)"
    if rsi <= 30:
        return 1, f"RSI={rsi:.1f} در محدوده اشباع فروش (احتمال برگشت)"
    if rsi > 55:
        return 1, f"RSI={rsi:.1f} تمایل صعودی"
    if rsi < 45:
        return -1, f"RSI={rsi:.1f} تمایل نزولی"
    return 0, f"RSI={rsi:.1f} خنثی"


def _score_ma_cross(row: pd.Series) -> tuple[float, str]:
    price, sma, ema = row["close"], row["sma"], row["ema"]
    if price > ema > sma:
        return 2, "قیمت بالای EMA و EMA بالای SMA (روند صعودی)"
    if price < ema < sma:
        return -2, "قیمت زیر EMA و EMA زیر SMA (روند نزولی)"
    if price > sma:
        return 1, "قیمت بالای میانگین متحرک ساده"
    if price < sma:
        return -1, "قیمت زیر میانگین متحرک ساده"
    return 0, "قیمت نزدیک میانگین‌های متحرک"


def _score_bbands(row: pd.Series) -> tuple[float, str]:
    pct = row["bb_percent"]
    if pct >= 1:
        return -1, "قیمت بالای باند بالایی بولینگر (احتمال اصلاح)"
    if pct <= 0:
        return 1, "قیمت زیر باند پایینی بولینگر (احتمال برگشت)"
    if pct > 0.8:
        return -0.5, "قیمت نزدیک باند بالایی بولینگر"
    if pct < 0.2:
        return 0.5, "قیمت نزدیک باند پایینی بولینگر"
    return 0, "قیمت در میانه باندهای بولینگر"


def _adx_strength_multiplier(row: pd.Series) -> tuple[float, str]:
    adx = row["adx"]
    if adx >= 40:
        return 1.3, f"ADX={adx:.1f} روند بسیار قوی"
    if adx >= 25:
        return 1.15, f"ADX={adx:.1f} روند قابل‌اتکا"
    if adx >= 15:
        return 1.0, f"ADX={adx:.1f} روند متوسط"
    return 0.7, f"ADX={adx:.1f} روند ضعیف/بدون روند مشخص"


def _volatility_note(row: pd.Series) -> str:
    atr = row["atr"]
    atr_pct = (atr / row["close"]) * 100 if row["close"] else 0
    return f"ATR={atr:,.0f} (~{atr_pct:.2f}% از قیمت) به‌عنوان معیار نوسان"


def analyze(row: pd.Series) -> SignalResult:
    """
    ردیف آخر اندیکاتورها را گرفته و یک SignalResult (روند + قدرت + دلایل)
    برمی‌گرداند.
    """
    reasons: list[str] = []
    total_score = 0.0
    max_possible = 0.0

    for score_fn, weight in (
        (_score_macd, 2),
        (_score_rsi, 1.5),
        (_score_ma_cross, 2),
        (_score_bbands, 1),
    ):
        score, reason = score_fn(row)
        total_score += score * weight
        max_possible += 2 * weight
        reasons.append(reason)

    multiplier, adx_reason = _adx_strength_multiplier(row)
    reasons.append(adx_reason)
    reasons.append(_volatility_note(row))

    total_score *= multiplier

    # نرمالایز کردن امتیاز به بازه‌ی 0..100 برای "قدرت سیگنال"
    normalized = max(-1.0, min(1.0, total_score / max_possible)) if max_possible else 0.0
    strength = round(abs(normalized) * 100)

    if normalized >= 0.5:
        trend = "صعودی قوی"
    elif normalized >= 0.15:
        trend = "صعودی"
    elif normalized <= -0.5:
        trend = "نزولی قوی"
    elif normalized <= -0.15:
        trend = "نزولی"
    else:
        trend = "خنثی"

    return SignalResult(trend=trend, strength=strength, reasons=reasons)
